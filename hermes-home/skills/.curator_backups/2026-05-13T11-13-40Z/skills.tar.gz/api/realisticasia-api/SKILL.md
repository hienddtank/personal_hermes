---
name: RealisticAsia API
description: Access the RealisticAsia travel/tourism management platform API and admin UI. Covers tour CRUD, itineraries, accommodations, authentication, DOCX content import, browser harness fallback, and established workflows.
category: api
parameters:
  - name: token
    type: string
    description: Authentication bearer token (required for write operations)
---

**API Base URL:** `https://api.realisticasia.com/v1`
**Admin UI:** `https://admin.realisticasia.com`
**Public Site:** `https://realisticasia.com`
**Tour DOCX source:** `/host/d/mkt/python/hermes/workspace/tours/` (Windows D: drive)

## Quick Reference

| Operation | Method | Endpoint | Auth? |
|-----------|--------|----------|-------|
| Login | POST | `/v1/auth/login` | No |
| List tours | GET | `/v1/travel/tour` | No (public) |
| Get tour | GET | `/v1/travel/tour/{id}` | No |
| Create tour | POST | `/v1/travel/tour` | Yes |
| **Update tour** | **POST** | `/v1/travel/tour/{id}` | Yes |
| Delete tour | DELETE | `/v1/travel/tour/{id}` | Yes |
| List accommodations | GET | `/v1/travel/accommodation` | No |
| Create accommodation | POST | `/v1/travel/accommodation` | Yes |

## Authentication

### Login (Verified Working)
```python
import urllib.request, json

creds = {"email": "<email>", "password": "<password>"}
req = urllib.request.Request(
    "https://api.realisticasia.com/v1/auth/login",
    data=json.dumps(creds).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
resp = urllib.request.urlopen(req)
resp_data = json.loads(resp.read())
token = resp_data['access_token']  # Dict with access_token key
```

**Token format:** `{number}|{hash}` (e.g., `748|b94...`)
**Stored credentials:** `/tmp/cred.json` (JSON with `email` and `password` keys)

### Auth Header
```
Authorization: Bearer <token>
```

### Verify Token
```python
req = urllib.request.Request("https://api.realisticasia.com/v1/auth/user")
req.add_header('Authorization', f'Bearer {token}')
resp = urllib.request.urlopen(req)
print(json.loads(resp.read()))  # Returns user info
```

## Response Format

All API responses wrapped in `{"data": ...}` (except auth login which returns dict with `access_token` key):
```json
{"data": {...}}      // single resource or success
{"data": [...]}      // list of resources
{"error": "..."}     // error response
```

Status codes: `200` (success), `401` (unauthorized), `404` (not found), `405` (method not allowed), `500` (server error)

## Tour Operations

### GET Tour (Full Object)
```python
req = urllib.request.Request(f"https://api.realisticasia.com/v1/travel/tour/{tour_id}")
resp = urllib.request.urlopen(req)
tour = json.loads(resp.read())['data']
```

**Tour structure:**
```json
{
  "data": {
    "id": 561,
    "name": "Tour Name",
    "slug": "tour-name",
    "duration": 5,
    "introduction": "<p>HTML description</p>",
    "start_city_id": null,
    "end_city_id": null,
    "group_type_id": 2,
    "guide_type_id": 3,
    "budget_class_id": 3,
    "travel_style_id": 6,
    "status": 0,
    "is_ready_to_book": 1,
    "min_group_size": 2,
    "max_group_size": 15,
    "traveller_type_ids": [2, 3],
    "itineraries": [
      {
        "id": 6235,
        "day_from": 1,
        "day_to": 1,
        "tour_id": 561,
        "title": "Day Title",
        "description": "<p>HTML content</p>",
        "order": 1,
        "image": [],
        "city_ids": [],
        "cities": [],
        "accommodation_ids": [],
        "accommodations": [],
        "meal_ids": [],
        "meals": []
      }
    ],
    "cities": [...],
    "accommodations": [...],
    "travellerTypes": [...]
  }
}
```

### Update Tour — ⚠️ Use POST, NOT PUT/PATCH

**CRITICAL:** The Laravel API rejects PUT and PATCH on resource routes with `405 Method Not Allowed`. `X-HTTP-Method-Override` also fails. **Always use POST to update.**

```python
token = "..."
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# 1. GET the current tour first
req = urllib.request.Request(f"https://api.realisticasia.com/v1/travel/tour/{tour_id}")
resp = urllib.request.urlopen(req)
tour = json.loads(resp.read())['data']

# 2. Modify what you need
for it in tour['itineraries']:
    day = it['day_from']
    it['title'] = f'New title for day {day}'
    it['description'] = f'<p>New HTML description - day {day}</p>'

# 3. POST to update (send FULL tour object)
req = urllib.request.Request(
    f"https://api.realisticasia.com/v1/travel/tour/{tour_id}",
    data=json.dumps(tour).encode(),
    headers=headers,
    method="POST"
)
resp = urllib.request.urlopen(req)
result = json.loads(resp.read())['data']
print(f"Updated tour {result['id']}")
```

### Required Fields on POST Update

When updating, include ALL of these fields (GET them first):
- `name`, `slug`, `duration`
- `introduction` (HTML)
- `start_city_id`, `end_city_id`
- `group_type_id`, `guide_type_id`
- `budget_class_id`, `travel_style_id`
- `status`, `is_ready_to_book`
- `traveller_type_ids`
- `itineraries` (array — updates inline)
- `min_group_size`, `max_group_size`

### Itinerary Fields
Each itinerary has: `id`, `day_from`, `day_to`, `tour_id`, `title`, `description`, `order`, `image`, `city_ids`, `cities`, `accommodation_ids`, `accommodations`, `meal_ids`, `meals`

- `title`: plain text
- `description`: HTML format (`<p>...</p>`)
- `day_from`/`day_to`: integer day range
- **Adding new itineraries:** Omit the `id` field — API auto-generates. Include all other fields.
- **Removing itineraries:** Filter from the array before POSTing (no separate delete endpoint).
- **Updating existing:** Preserve `id` to update in place.

### Status Codes
- `status`: `0` = Inactive/Draft, `1` = Active/Published
- `is_ready_to_book`: `1` = bookable, `0` = not ready

## Known Limitations

1. **PUT/PATCH blocked** — Always use POST for updates
2. **Accommodation pivot descriptions** cannot be updated via tour POST endpoint
3. **Full object required** — GET then POST entire tour object, not partial updates
4. **No batch operations** — Each resource update is individual
5. **No itinerary delete endpoint** — Remove by filtering from array
6. **City lookup:** No `/v1/travel/city` endpoint (404). Discover cities by scanning tour listings or GETting individual tours.
7. **500 errors:** Common on malformed payloads (extra itineraries, missing IDs, wrong types). Always check error body: `e.read().decode()`

## Import Tour from DOCX

Standard workflow for uploading tour content from Word documents stored at `D:\mkt\python\hermes\workspace\tours\`:

```python
import docx, urllib.request, json

# 1. Read DOCX
doc = docx.Document("/host/d/mkt/python/hermes/workspace/tours/your_tour.docx")

# 2. Extract introduction from first table row
intro = ""
for row in doc.tables[0].rows:
    for cell in row.cells:
        intro += cell.text.strip() + " "
intro = f"<p>{intro.strip()}</p>"

# 3. Parse day-based paragraphs with regex
import re
days_data = {}
current_day = None
for p in doc.paragraphs:
    text = p.text.strip()
    m = re.match(r'(DAY\s*0*\d+|DAY\s*5):\s*(.*)', text)
    if m:
        day_num = int(m.group(1).replace('DAY','').strip())
        current_day = day_num
        days_data[day_num] = {'title': re.sub(r'\s*\(.*\)\s*$', '', m.group(2)), 'content': []}
    elif current_day and text:
        days_data[current_day]['content'].append(text)

# 4. Build itineraries
itineraries = []
for d in range(1, 6):
    dd = days_data.get(d, {'title': f'Day {d}', 'content': ['No content']})
    itineraries.append({
        "day_from": d, "day_to": d, "tour_id": tour_id,
        "title": dd['title'],
        "description": ''.join(f"<p>{c}</p>" for c in dd['content']),
        "order": d,
        "image": [], "city_ids": [], "cities": [],
        "accommodation_ids": [], "accommodations": [],
        "meal_ids": [], "meals": []
    })
```

**Pitfalls:**
- DOCX paragraphs may be truncated in print output — always check `len(text)`
- Day headers use regex: `DAY\s*0*\d+` (handles "DAY 01", "DAY 1", "DAY 5")
- Meal indicators in parentheses `(B)`, `(-)` should be stripped from titles
- Stop parsing at sections like "QUOTATION", "ACCOMODATION" — use early break
- **AMPERSAND TRAP:** Python heredocs (`<< 'EOF'`) interpret `&` as background process. Always write scripts to `/tmp/file.py` and run via `python3 /tmp/file.py` instead of inline heredocs.
- Title convention: prefix with "hermes - " for test tours per user preference

## Admin UI (Browser Harness)

### Access
- URL: `https://admin.realisticasia.com`
- Credentials: same as API (stored in `/tmp/cred.json`)
- Login at `/auth/login`

### When to Use API vs UI
| Task | Preferred Method | Reason |
|------|-----------------|--------|
| Read tour data | **API** | Structured, fast |
| Update itineraries | **API** | Direct field control |
| Create tours | **API** | Programmatic |
| Delete resources | **API** (if endpoint) or **UI** | No itinerary delete endpoint |
| Visual verification | **UI** | See rendered output |

## Workflow: Edit Tour Itineraries
1. `POST /v1/auth/login` → get token
2. `GET /v1/travel/tour/{id}` → fetch full tour object
3. Modify `itineraries` array (title, description)
4. `POST /v1/travel/tour/{id}` → send full modified object
5. Verify: GET again or screenshot admin UI

## Workflow: Create New Tour
1. Login to get token
2. Construct tour object with all required fields
3. `POST /v1/travel/tour` → returns new tour with ID
4. Optional: Update itineraries via POST to `/v1/travel/tour/{new_id}`

## Workflow: Import from DOCX
1. Locate DOCX in `/host/d/mkt/python/hermes/workspace/tours/`
2. Extract content (see Import section above)
3. GET tour → modify → POST full object
4. Verify via GET or admin UI

## Notes
- All timestamps are ISO 8601 (UTC)
- IDs are auto-incrementing integers
- Descriptions use HTML format
- API documentation: `https://api.realisticasia.com/docs/api`
- User quarantines test tours for safe experimentation
- Reference session detail: `references/tour555-debug-notes.md`, `references/tour561-myanmar-upload.md`

parameters:
  - name: token
    type: string
    description: Authentication bearer token (required for ALL operations)
---

**API Base URL:** `https://api.realisticasia.com/v1`
**Admin UI:** `https://admin.realisticasia.com`
**Public Site:** `https://realisticasia.com`

## Quick Reference

| Operation | Method | Endpoint | Auth? |
|-----------|--------|----------|-------|
| Login | POST | `/v1/auth/login` | No |
| List tours | GET | `/v1/travel/tour` | **Yes** (see pitfalls) |
| Get tour | GET | `/v1/travel/tour/{id}` | **Yes** |
| Create tour | POST | `/v1/travel/tour` | Yes |
| **Update tour** | **POST** | `/v1/travel/tour/{id}` | Yes |
| Delete tour | DELETE | `/v1/travel/tour/{id}` | Yes |
| List accommodations | GET | `/v1/travel/accommodation` | No |
| Create accommodation | POST | `/v1/travel/accommodation` | Yes |

## Authentication

### Login (Verified Working)
```python
import urllib.request, json

creds = {"email": "<email>", "password": "<password>"}
req = urllib.request.Request(
    "https://api.realisticasia.com/v1/auth/login",
    data=json.dumps(creds).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
login_data = json.loads(urllib.request.urlopen(req).read())
token = login_data['access_token']  # Response is {"access_token": "...", "token_type": "Bearer"}
print(f"Token: {token}")
```

**Auth response format:** `{"access_token": "<token>", "token_type": "Bearer"}` — NOT a raw string, NOT wrapped in `{"data": ...}`. Extract via `response['access_token']`.

**Token format:** `{number}|{hash}` (e.g., `748|b94PBbd...`)
**Stored credentials:** `/tmp/cred.json` (JSON with `email` and `password` keys)

### Auth Header
```
Authorization: Bearer <token>
```

### Verify Token
```python
req = urllib.request.Request("https://api.realisticasia.com/v1/auth/user")
req.add_header('Authorization', f'Bearer {token}')
resp = urllib.request.urlopen(req)
print(json.loads(resp.read()))  # Returns user info
```

## Response Format

All API responses wrapped in `{"data": ...}` (except auth login which returns the token dict):
```json
{"data": {...}}      // single resource or success
{"data": [...]}      // list of resources
{"error": "..."}     // error response
```

Status codes: `200` (success), `401` (unauthorized), `404` (not found), `405` (method not allowed), `500` (server error)

## Tour Operations

### GET Tour (Full Object)
```python
req = urllib.request.Request(f"https://api.realisticasia.com/v1/travel/tour/{tour_id}")
resp = urllib.request.urlopen(req)
tour = json.loads(resp.read())['data']
```

**Tour structure:**
```json
{
  "data": {
    "id": 555,
    "name": "Tour Name",
    "slug": "tour-name",
    "duration": 5,
    "introduction": "<p>HTML description</p>",
    "start_city_id": 48,
    "end_city_id": 48,
    "group_type_id": 2,
    "guide_type_id": 3,
    "budget_class_id": 3,
    "travel_style_id": 12,
    "status": 0,
    "is_ready_to_book": 1,
    "itineraries": [
      {
        "id": 6229,
        "day_from": 1,
        "day_to": 1,
        "tour_id": 555,
        "title": "Day Title",
        "description": "<p>HTML content</p>",
        "order": 1,
        "image": [],
        "city_ids": [],
        "cities": [],
        "accommodation_ids": [],
        "accommodations": [],
        "meal_ids": [],
        "meals": []
      }
    ],
    "cities": [...],
    "accommodations": [...],
    "travellerTypes": [...]
  }
}
```

### Update Tour — ⚠️ Use POST, NOT PUT/PATCH

**CRITICAL:** The Laravel API rejects PUT and PATCH on resource routes with `405 Method Not Allowed`. `X-HTTP-Method-Override` also fails. **Always use POST to update.**

```python
token = "..."
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# 1. GET the current tour first
req = urllib.request.Request(f"https://api.realisticasia.com/v1/travel/tour/{tour_id}")
resp = urllib.request.urlopen(req)
tour = json.loads(resp.read())['data']

# 2. Modify what you need
for it in tour['itineraries']:
    day = it['day_from']
    it['title'] = f'New title for day {day}'
    it['description'] = f'<p>New HTML description - day {day}</p>'

# 3. POST to update (send FULL tour object)
req = urllib.request.Request(
    f"https://api.realisticasia.com/v1/travel/tour/{tour_id}",
    data=json.dumps(tour).encode(),
    headers=headers,
    method="POST"
)
resp = urllib.request.urlopen(req)
result = json.loads(resp.read())['data']
print(f"Updated tour {result['id']}")
```

### Adding New Itineraries

When adding new itinerary days, append items WITHOUT an `id` field — the server auto-assigns IDs:

```python
# Keep existing (preserve their ids)
tour['itineraries'][0]['title'] = 'Day 1 - Updated'

# Add new (no id — server assigns one)
tour['itineraries'].append({
    "day_from": 4,
    "day_to": 4,
    "tour_id": tour['id'],
    "title": "Day 4 Title",
    "description": "<p>Day 4 HTML content</p>",
    "order": 4,
    "image": [],
    "city_ids": [],
    "cities": [],
    "accommodation_ids": [],
    "accommodations": [],
    "meal_ids": [],
    "meals": []
})
```

Server returns the updated tour with new IDs assigned to previously-idless items.

### Required Fields on POST Update

When updating, include ALL of these fields (GET them first):
- `name`, `slug`, `duration`
- `introduction` (HTML)
- `start_city_id`, `end_city_id`
- `group_type_id`, `guide_type_id`
- `budget_class_id`, `travel_style_id`
- `status`, `is_ready_to_book`
- `traveller_type_ids`
- `itineraries` (array — updates inline)

### Itinerary Fields
Each itinerary has: `id`, `day_from`, `day_to`, `tour_id`, `title`, `description`, `order`, `image`, `city_ids`, `cities`, `accommodation_ids`, `accommodations`, `meal_ids`, `meals`

- `title`: plain text
- `description`: HTML format (`<p>...</p>`)
- `day_from`/`day_to`: integer day range
- `id`: auto-assigned for new items, preserved for existing

### Status Codes
- `status`: `0` = Inactive/Draft, `1` = Active/Published
- `is_ready_to_book`: `1` = bookable, `0` = not ready

## Known Pitfalls

1. **PUT/PATCH blocked** — Always use POST for updates
2. **Auth required for ALL endpoints** — Even "public" GET endpoints return `{"Hello": "World"}` without auth. Always include `Authorization: Bearer <token>` headers on every request.
3. **500 errors may partially commit** — A POST that returns HTTP 500 can still persist some field changes. Always GET the tour again after a failed POST to check actual state before retrying.
4. **Accommodation pivot descriptions** cannot be updated via the tour POST endpoint. They persist unchanged. No known API endpoint to update pivot data directly.
5. **Full object required** — You must GET then POST the entire tour object, not partial updates
6. **No batch operations** — Each resource update is individual
7. **No city lookup endpoint** — `GET /v1/travel/city` returns 404. Find city IDs by reading tours and collecting their `cities` arrays.
8. **`&` in Python heredocs** — When running multi-line Python via `python3 << 'EOF'`, the `&` character is interpreted as shell backgrounding. Write to a `.py` file instead and run with `python3 script.py`.

## Admin UI (Browser Harness)

When the API lacks an endpoint or you need visual verification:

### Access
- URL: `https://admin.realisticasia.com`
- Credentials: same as API (stored in `/tmp/cred.json`)
- Login page at `/auth/login`

### Browser Harness Pattern
```python
# Check tour details
terminal(browser_harness_command={
    "url": "https://admin.realisticasia.com/tour/<id>",
    "action": "screenshot"
})
```

### When to Use API vs UI
| Task | Preferred Method | Reason |
|------|-----------------|--------|
| Read tour data | **API** | Structured, fast |
| Update itineraries | **API** | Direct field control |
| Create tours | **API** | Programmatic |
| Delete resources | **API** (if endpoint exists) or **UI** | No known itinerary delete endpoint |
| Visual verification | **UI** | See rendered output |
| Complex form edits | **UI** | Multi-step workflows with hidden fields |

## Workflows

### Edit Tour Itineraries
1. `POST /v1/auth/login` → extract `access_token`
2. `GET /v1/travel/tour/{id}` → fetch full tour object (with auth header)
3. Modify `itineraries` array (title, description, day_from)
4. For new days: append items without `id` field
5. `POST /v1/travel/tour/{id}` → send full modified object
6. Verify: GET again or screenshot admin UI

### Create New Tour
1. Login to get token
2. Construct tour object with all required fields
3. `POST /v1/travel/tour` → returns new tour with ID
4. Optional: Update itineraries via POST to `/v1/travel/tour/{new_id}`

## Supporting Files
- `references/auth-and-quirks.md` — Auth response format details, endpoint quirks, pagination patterns
- `scripts/update-tour.py` — Reusable CLI script for authenticated tour updates
- `templates/tour-update-scaffold.py` — Template for custom tour modifications

## Notes
- All timestamps are ISO 8601 (UTC)
- IDs are auto-incrementing integers
- Descriptions use HTML format
- API documentation: `https://api.realisticasia.com/docs/api`
